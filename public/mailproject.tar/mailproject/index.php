<?php

require 'vendor/autoload.php';
use Mailgun\Mailgun;
$mailgun = new Mailgun('key-c5a7121da9a0dbb79187d69088419555', new \Http\Adapter\Guzzle6\Client());
//print_r(get_declared_classes());

print_r( get_class_methods("Mailgun\Mailgun"));
# Now, compose and send your message.
$mailgun->sendmessage('rg.christadelphianmyc.com', [
  'from'    => 'postmaster@rg.christadelphianmyc.com', 
  'to'      => 'andrew.c.corbin@gmail.com', 
  'subject' => 'The PHP SDK is awesome!', 
  'text'    => 'It is so simple to send a message.'
]);
